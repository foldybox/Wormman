﻿//Level.cpp

#include <gl/glut.h>
#include "Utils.h"
#include "Level.h"

void Level::draw()
{
	glMaterialfv(GL_FRONT, GL_AMBIENT, getAmbiColor());
	glMaterialfv(GL_FRONT, GL_DIFFUSE, getDiffColor());
	glMaterialfv(GL_FRONT, GL_SPECULAR, getSpecColor());
	glMaterialf(GL_FRONT, GL_SHININESS, GraphUtils::shininess);
	// Запис поточної матриці в стек
	// (збереження вмісту поточної матриці для подальшого використання):
	glPushMatrix();
	glTranslatef(getXCenter(), getYCenter(), getZCenter());
	GraphUtils::parallelepiped(getXSize(), getYSize(), getZSize());
	// Відновлення поточної матриці зі стека:
	glPopMatrix();
}